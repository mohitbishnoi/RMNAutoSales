```bash
pip install tkinter ttkwidgets tksheet mysql-connector-python
```

Run:
```commandline
python3 rmn_auto_sales.py
```
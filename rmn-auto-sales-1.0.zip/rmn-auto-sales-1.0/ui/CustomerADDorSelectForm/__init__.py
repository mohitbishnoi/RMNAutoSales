from ui.CustomerADDorSelectForm import CustomerADDorSelectForm


def showCustomerForm():
    CustomerADDorSelectForm.start_up()